package com.assignment.users;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import io.swagger.annotations.ApiParam;

@RestController
@EnableAutoConfiguration
public class GetUserInformationController {

	@RequestMapping(value = "/getAllUsers", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody ResponseEntity<Map<String, Object>> getAllUsers() {

		Map<String, Object> userMapData = new HashMap<String, Object>();
		try {
			userMapData = getPostCountAndDetails(false,null);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
			userMapData.put("Exception :", -1);
			return new ResponseEntity<Map<String, Object>>(userMapData, HttpStatus.BAD_REQUEST);
		}

		return new ResponseEntity<Map<String, Object>>(userMapData, HttpStatus.OK);
	}

	private Map<String, Object> getPostCountAndDetails(boolean flowType,String userID) throws ParseException {
		boolean isSameUser = false;
		final String uri = "https://jsonplaceholder.typicode.com/posts";
		RestTemplate restTemplate = new RestTemplate();
		String result = restTemplate.getForObject(uri, String.class);
		JSONParser jsonParser = new JSONParser();
		Object obj = jsonParser.parse(result);
		JSONArray userList = (JSONArray) obj;
		List<String> specificPostDetailsList = new ArrayList<String>();
		Map<String, Object> userMap = new HashMap<String, Object>();

		String userId = null;
		int postCount = 0;
		// Iterate over userList array
		for (int i = 0; i < userList.size(); i++) {
			JSONObject userObj = (JSONObject) userList.get(i);
			
			if(null != userID && flowType && userID.equalsIgnoreCase(userObj.get("userId").toString())){
				specificPostDetailsList.add(userObj.get("id").toString());
				specificPostDetailsList.add(userObj.get("title").toString());
				specificPostDetailsList.add(userObj.get("body").toString());
			}
				

			if (null != userId && userId.equalsIgnoreCase(userObj.get("userId").toString())) {
				postCount = postCount + 1;
				isSameUser = true;
			} else {
				isSameUser = false;
				if (userList.size() > 1 && i != 0)
					userMap.put(userId, postCount);
				else if (userList.size() == 1)
					userMap.put(userObj.get("userId").toString(), postCount++);

				if (!isSameUser)
					postCount = 0;

			}
			if (i == userList.size() - 1)
				userMap.put(userObj.get("userId").toString(), postCount);

			userId = userObj.get("userId").toString();
		}
		
		if(specificPostDetailsList.size() > 0)
			userMap.put(userID, specificPostDetailsList);
		
		return userMap;
	}

	@RequestMapping(value = "/getUserDetail/{userID}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public @ResponseBody ResponseEntity<Map<String, Object>> getUserDetail(
			@ApiParam(value = "user Id", required = true) @PathVariable String userID, HttpServletRequest request,
			HttpServletResponse response) {
		final String uri = "https://jsonplaceholder.typicode.com/users/" + userID;

		RestTemplate restTemplate = new RestTemplate();
		String result = restTemplate.getForObject(uri, String.class);

		JSONParser jsonParser = new JSONParser();

		Map<String, Object> userMapData = new HashMap<String, Object>();
		try {
			Object obj = jsonParser.parse(result);
			JSONObject userObj = (JSONObject) obj;
			userMapData.put("name", userObj.get("name").toString());
			userMapData.put("email", userObj.get("email").toString());
			
			userMapData.put("postDetails",getPostCountAndDetails(true, userID));

		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			userMapData.put("Exception :", "-1");
			return new ResponseEntity<Map<String, Object>>(userMapData, HttpStatus.BAD_REQUEST);
		}

		return new ResponseEntity<Map<String, Object>>(userMapData, HttpStatus.OK);
	}

	public static void main(String[] args) throws Exception {
		SpringApplication.run(GetUserInformationController.class, args);
	}
}
